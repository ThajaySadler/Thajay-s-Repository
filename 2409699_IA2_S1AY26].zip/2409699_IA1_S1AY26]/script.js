// Name: Thajay Sadler       
// ID: 2409699
// Faculty: FENC 

// IA#2 JS - PS5 Gaming Accessories Store

// CART STORAGE FUNCTIONS
function loadCart() {
    return JSON.parse(localStorage.getItem("cart")) || [];
}

function saveCart(cart) {
    localStorage.setItem("cart", JSON.stringify(cart));
}

// ADD TO CART FUNCTIONALITY
document.addEventListener("DOMContentLoaded", () => {
    const addButtons = document.querySelectorAll(".addToCart");

    addButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            const id = Number(btn.dataset.id);
            const name = btn.dataset.name;
            const price = Number(btn.dataset.price);

            let cart = loadCart();
            let found = cart.find(p => p.id === id);

            if (found) {
                found.qty++;
            } else {
                cart.push({ id, name, price, qty: 1 });
            }

            saveCart(cart);
            alert(`${name} added to cart!`);
            renderCart();
        });
    });

    // FORM VALIDATION SETUP
    setupValidation();

    renderCart();
    renderSummary();

    // ============================
    // CHECKOUT PAGE BUTTONS
    // ============================

    // CLEAR ALL BUTTON
    const clearBtn = document.getElementById("clearAllBtn");
    if (clearBtn) {
        clearBtn.addEventListener("click", () => {
            localStorage.removeItem("cart");
            alert("All items have been cleared.");
            location.reload();
        });
    }

    // CHECK OUT BUTTON (scrolls to payment)
    const checkoutBtn = document.getElementById("checkoutBtn");
    if (checkoutBtn) {
        checkoutBtn.addEventListener("click", () => {
            const paymentHeader = document.querySelector("h2:nth-of-type(2)");
            if (paymentHeader) paymentHeader.scrollIntoView({ behavior: "smooth" });
        });
    }

    // CANCEL BUTTON → return to cart
    const cancelBtn = document.getElementById("cancelBtn");
    if (cancelBtn) {
        cancelBtn.addEventListener("click", () => {
            window.location.href = "cart.html";
        });
    }

    // CLOSE BUTTON → return to home
    const closeBtn = document.getElementById("closeBtn");
    if (closeBtn) {
        closeBtn.addEventListener("click", () => {
            window.location.href = "index.html";
        });
    }
});

// RENDER CART TABLE
function renderCart() {
    const table = document.getElementById("cartBody");
    if (!table) return;

    let cart = loadCart();
    table.innerHTML = "";
    let subtotal = 0;

    cart.forEach((item, index) => {
        let rowTotal = item.qty * item.price;
        subtotal += rowTotal;

        table.innerHTML += `
            <tr>
                <td>${item.name}</td>
                <td>$${item.price.toFixed(2)}</td>
                <td>${item.qty}</td>
                <td>$${rowTotal.toFixed(2)}</td>
                <td><button class="removeItem" data-index="${index}">X</button></td>
            </tr>
        `;
    });

    let tax = subtotal * 0.15;
    let total = subtotal + tax;

    const summary = document.getElementById("cartTotal");
    if (summary) {
        summary.innerHTML = `Subtotal: $${subtotal.toFixed(2)} | 
                             Tax (15%): $${tax.toFixed(2)} | 
                             Total: $${total.toFixed(2)}`;
    }

    document.querySelectorAll(".removeItem").forEach(btn => {
        btn.addEventListener("click", () => {
            let cart = loadCart();
            cart.splice(btn.dataset.index, 1);
            saveCart(cart);
            renderCart();
        });
    });
}

// CLEAR CART
function clearCart() {
    localStorage.removeItem("cart");
    renderCart();
}

// CHECKOUT SUMMARY
function renderSummary() {
    const box = document.getElementById("summary");
    if (!box) return;

    let cart = loadCart();
    let subtotal = cart.reduce((t, i) => t + i.price * i.qty, 0);
    let tax = subtotal * 0.15;
    let total = subtotal + tax;

    box.innerHTML = `
        <p>Subtotal: $${subtotal.toFixed(2)}</p>
        <p>Tax (15%): $${tax.toFixed(2)}</p>
        <p><strong>Total: $${total.toFixed(2)}</strong></p>
    `;

    const amount = document.getElementById("amount");
    if (amount) amount.value = total.toFixed(2);
}

// FORM VALIDATION (LOGIN, REGISTER, CHECKOUT)
function setupValidation() {

    // LOGIN VALIDATION
    const login = document.getElementById("loginForm");
    if (login) {
        login.addEventListener("submit", e => {
            if (!login.username.value || !login.password.value) {
                e.preventDefault();
                alert("Please enter both username and password.");
            }
        });
    }

    // REGISTER VALIDATION
    const reg = document.getElementById("registerForm");
    if (reg) {
        reg.addEventListener("submit", e => {
            if (!reg.email.value.includes("@") ||
                !reg.username.value.trim() ||
                !reg.password.value.trim()) 
            {
                e.preventDefault();
                alert("Please fill out all fields correctly.");
            }
        });
    }

    // CHECKOUT VALIDATION (NOW COMPLETES ORDER)
    const checkout = document.getElementById("checkoutForm");
    if (checkout) {
        checkout.addEventListener("submit", e => {

            e.preventDefault(); // We handle the process manually

            // SHIPPING FIELDS
            if (!checkout.name.value.trim() ||
                !checkout.address.value.trim() ||
                !checkout.city.value.trim() ||
                !checkout.postal.value.trim()) 
            {
                alert("Please complete all shipping fields.");
                return;
            }

            // PAYMENT FIELDS
            const cardName = checkout.cardName.value.trim();
            const cardNumber = checkout.cardNumber.value.replace(/\s+/g, "");
            const expiry = checkout.expiry.value.trim();
            const cvv = checkout.cvv.value.trim();

            if (cardName.length < 3) {
                alert("Please enter the name on the card.");
                return;
            }

            if (!/^\d{16}$/.test(cardNumber)) {
                alert("Please enter a valid 16-digit card number.");
                return;
            }

            if (!/^\d{2}\/\d{2}$/.test(expiry)) {
                alert("Expiry date must be in MM/YY format.");
                return;
            }

            const [mm, yy] = expiry.split("/").map(Number);
            const now = new Date();
            const expiryDate = new Date(2000 + yy, mm - 1);

            if (expiryDate < now) {
                alert("Your card is expired.");
                return;
            }

            if (!/^\d{3}$/.test(cvv)) {
                alert("Please enter a valid 3-digit CVV number.");
                return;
            }

            // ============================
            // PAYMENT SUCCESS ACTION
            // ============================

            alert("Payment Successful! Order Confirmed!");

            // Clear the cart
            localStorage.removeItem("cart");

            // Redirect home
            window.location.href = "index.html";
        });
    }
}
